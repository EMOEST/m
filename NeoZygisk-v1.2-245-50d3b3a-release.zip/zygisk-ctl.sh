MODDIR=${0%/*}/..

export TMP_PATH=/data/adb/neozygisk

exec $MODDIR/bin/zygisk-ptrace64 ctl $*
